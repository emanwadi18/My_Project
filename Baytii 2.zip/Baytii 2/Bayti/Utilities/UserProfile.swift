

import Foundation
import UIKit

class UserProfile {
    
    private static var object: UserProfile?
    
    private init() {}
    
    var fcmToken = String()
    
    public static var shared: UserProfile {
        
        if object == nil {
            object = UserProfile()
        }
        return object!
    }
    
    private let KEY_USER = "USER"
    private let KEY_CITY_ID = "CITYID"
    private let KEY_PROFILE = "PROFILE"
    private let KEY_CART_COUNT = "CART_COUNT"
    private let KEY_NOTIFICATION_COUNT = "NOTIFICATION_COUNT"
    private let KEY_IS_FIRST_RUN = "IS_FIRST_RUN"
    private let KEY_APPEL_LANGUAGE = "AppleLanguages"
    private let KEY_CURRENT_VIEW_ROLE = "CURRENT_VIEW_ROLE"
    private let KEY_REMEMBERME = "KEY_REMEMBERME"
    private let KEY_PRIVASELOCK = "PRIVASYLOCK"
    private let KEY_LOCAL_COUNTRY = "LOCAL_COUNTRY"
    
    private var userDefaults = UserDefaults.standard
    
    // MARK: - language
    
    public var language: [String]? {
        get {
            try? self.userDefaults.getObject(forKey: KEY_APPEL_LANGUAGE, castTo: [String].self)
        }
        set {
            try? self.userDefaults.setObject(newValue ?? [], forKey: KEY_APPEL_LANGUAGE)
        }
    }
    
    //    // MARK: - USER
//    //
//    public var user: User? {
//        get {
//            try? self.userDefaults.getObject(forKey: KEY_USER, castTo: User.self)
//        }
//        set {
//            try? self.userDefaults.setObject(newValue!, forKey: KEY_USER)
//        }
//    }
    
    public var cityID: Int? {
        get {
            self.userDefaults.integer(forKey: KEY_CITY_ID)
        }
        set {
            self.userDefaults.set(newValue, forKey: KEY_CITY_ID)
        }
    }
    
    private func removeUser() {
        self.userDefaults.removeObject(forKey: KEY_USER)
        self.userDefaults.removeObject(forKey: KEY_REMEMBERME)
    }
    
    
    ////
    public var cartCount: Int? {
        get {
            try? self.userDefaults.getObject(forKey: KEY_CART_COUNT, castTo: Int.self)
        }
        set {
            try? self.userDefaults.setObject(newValue!, forKey: KEY_CART_COUNT)
        }
    }
    
    public var notificationCount: Int? {
        get {
            try? self.userDefaults.getObject(forKey: KEY_NOTIFICATION_COUNT, castTo: Int.self)
        }
        set {
            try? self.userDefaults.setObject(newValue!, forKey: KEY_NOTIFICATION_COUNT)
        }
    }
    
    public func removeCounts() {
        self.userDefaults.removeObject(forKey: KEY_CART_COUNT)
        self.userDefaults.removeObject(forKey: KEY_NOTIFICATION_COUNT)
    }
    
    public func removeUnLock() {
        self.userDefaults.removeObject(forKey: KEY_PRIVASELOCK)
    }
    
    // MARK: - IS FIRST RUN
    
    func isFirstRun() -> Bool {
        let firstRunVar = userDefaults.string(forKey: KEY_IS_FIRST_RUN) ?? ""
        return firstRunVar.isEmpty
    }
    
    func rememberMe() -> Bool {
        let remeberMe = userDefaults.string(forKey: KEY_REMEMBERME) ?? ""
        return remeberMe.isNotEmpty
    }
    
    func PrivacyLock() -> Bool {
        let privacyLock = userDefaults.string(forKey: KEY_PRIVASELOCK) ?? ""
        return privacyLock.isNotEmpty
    }
    
    func changeFirstRunStatus() {
        userDefaults.set("exists", forKey: KEY_IS_FIRST_RUN)
    }
    
    func changeRememberMe() {
        userDefaults.set("remember", forKey: KEY_REMEMBERME)
    }
    
    func changePrivacyLock() {
        userDefaults.set("unLock", forKey: KEY_PRIVASELOCK)
    }
    
    //    MARK: - CURRENT VIEW ROLE
    
//    public var currentViewRole: UserRoles? {
//        get {
//            try? self.userDefaults.getObject(forKey: KEY_CURRENT_VIEW_ROLE, castTo: UserRoles.self)
//        }
//        set {
//            try? self.userDefaults.setObject(newValue!, forKey: KEY_CURRENT_VIEW_ROLE)
//        }
//    }
    
    public func removeCurrentViewRole() {
        self.userDefaults.removeObject(forKey: KEY_CURRENT_VIEW_ROLE)
    }
    
    // MARK: - IS LOGGED IN
    
//    public func isLoggedIn() -> Bool {
//        return self.user != nil
//    }
//
//    // MARK: - LOCAL COUNTRY
//
//    public var localCountry: MyAddress? {
//        get {
//            try? self.userDefaults.getObject(forKey: KEY_LOCAL_COUNTRY, castTo: MyAddress.self)
//        }
//        set {
//            try? self.userDefaults.setObject(newValue!, forKey: KEY_LOCAL_COUNTRY)
//        }
//    }
//
    public func removeLocalCountry() {
        self.userDefaults.removeObject(forKey: KEY_LOCAL_COUNTRY)
    }
    
//    public var isSelectedLocalCountry: Bool {
//        get {
//            return self.localCountry != nil
//        }
//    }
    
    
    
    public func logout() {
        self.removeUser()
    }
    
//    public func sendFCMToken(){
//        Messaging.messaging().token { token, error in
//            if let error = error {
//                print("Error fetching FCM registration token: \(error)")
//            } else if let token = token {
//                print("fcmToken == \(token)")
//                self.fcmToken = token
//            }
//        }
//
//        guard self.isLoggedIn(),
//              var user = self.user else {
//            return
//        }
//
//        user.fcm_token = self.fcmToken
//        RequestsManager().service.send(PublicRequestBuilder.updateProfile(user: user)) { (result: Result<BaseObjectResponse<User>, RequestErrors>) in
//            switch result {
//            case .success(_):
//                break
//
//            case .failure(let error):
//                print("Failure \(error.localizedDescription)")
//                break
//            }
//        }
//    }
}

extension UIViewController {
    
    var userProfile: UserProfile {
        get {
            return .shared
        }
    }
}
extension UIView {
    
    var userProfile: UserProfile {
        get {
            return .shared
        }
    }
}

