
import Foundation
import UIKit

//@IBDesignable
class ViewDesign: UIView {
    
    @IBInspectable var masksToBounds: Bool = false
    @IBInspectable var isCircle: Bool = false
    @IBInspectable var cornerRadius: CGFloat = 0
    
    @IBInspectable var borderWidth: CGFloat = 0
    @IBInspectable var borderColor: UIColor = .clear
    
    @IBInspectable var shadowColor: UIColor = .clear
    @IBInspectable var shadowOpacity: Float = 0
    @IBInspectable var shadowRadius: CGFloat = 0
    @IBInspectable var shadowOffset: CGSize = CGSize(width: 0, height: 0)
    
    var shadow: CustomShadow? = .default {
        willSet {
            guard let shadow = newValue else {
                self.shadowColor = .clear
                self.shadowOpacity = 0
                self.shadowRadius = 0
                self.shadowOffset = .zero
                return
            }
            
            self.shadowColor = shadow.color
            self.shadowOpacity = shadow.opacity
            self.shadowRadius = shadow.radius
            self.shadowOffset = shadow.offset
        }
    }
    
    private var cornerRadiusRect: UIRectCorner = .allCorners
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.cornerRadius = cornerRadius
        self.setCornerMask()
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = borderColor.cgColor
        
        self.layer.shadowColor = shadowColor.cgColor
        self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowRadius = shadowRadius
        self.layer.shadowOffset = shadowOffset
        self.layer.masksToBounds = masksToBounds
        
        setCorner()
    }
    
    public func setViewCorners(_ corners: UIRectCorner) {
        self.cornerRadiusRect = corners
        self.layoutSubviews()
    }
    
    private func setCornerMask() {
        
        let corners = self.cornerRadiusRect
        
        if #available(iOS 11, *) {
            var cornerMask = CACornerMask()

            if(corners.contains(.topLeft)){
                cornerMask.insert(.layerMinXMinYCorner)
            }
            if(corners.contains(.topRight)){
                cornerMask.insert(.layerMaxXMinYCorner)
            }
            if(corners.contains(.bottomLeft)){
                cornerMask.insert(.layerMinXMaxYCorner)
            }
            if(corners.contains(.bottomRight)){
                cornerMask.insert(.layerMaxXMaxYCorner)
            }
            
            self.layer.maskedCorners = cornerMask
            
        } else {
            let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: self.cornerRadius, height: self.cornerRadius))
            let mask = CAShapeLayer()
            mask.path = path.cgPath
            self.layer.mask = mask
        }
    }
    
    private func setCorner() {
        if self.isCircle {
            self.layer.cornerRadius = self.height / 2
        }
    }
}
