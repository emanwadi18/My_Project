
import Foundation
import UIKit

protocol CollectionCellSelectDelegate: AnyObject {
    func onCellSelected(_ selectedCell: UICollectionViewCell, object: Any)
}
