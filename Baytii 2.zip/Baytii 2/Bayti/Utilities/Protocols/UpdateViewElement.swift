
import Foundation
import UIKit

@objc
protocol UpdateViewElement {
    
    func elementUpdated(fromSourceView view: UIViewController, status: Bool, data: Any?)
    @objc optional func elementsUpdated(fromSourceView view: UIViewController, status: Bool, data: [Any]?)
}
