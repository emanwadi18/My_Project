
import Foundation
import UIKit

protocol CollectionCellDeleteDelegate: AnyObject {
    func onCellDeleted(_ deletedCell: UICollectionViewCell, id: Int)
}
