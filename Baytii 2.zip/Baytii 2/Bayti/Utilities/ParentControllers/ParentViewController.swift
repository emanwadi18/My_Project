

import UIKit
import Toast_Swift
//import FirebaseMessaging

class ParentViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
}

// MARK: - CUSTOM FUNCTIONS

extension ParentViewController {
    
//    public func showSnackMessage(_ message: String, duration: TTGSnackbarDuration = .short, background: UIColor = .systemRed, textColor: UIColor = .white) {
//        let snack = TTGSnackbar(message: message, duration: duration)
//        snack.backgroundColor = background
//        snack.messageTextColor = textColor
//        snack.cornerRadius = 6
//        snack.show()
//    }
    
    public func showConfirmation(message: String, _ okCompletion: @escaping VoidCompletion) {
        
        let alert = UIAlertController(title: "are_you_sure".localize(), message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "ok".localize(), style: .default, handler: { (action) in
            okCompletion()
        }))
        
        alert.addAction(UIAlertAction(title: "cancel".localize(), style: .cancel, handler: { (action) in
        }))
        
        self.present(alert, animated: true)
    }
    
    public func goBack() {
        self.navigationController?.popViewController(animated: true)
    }
    
//
//    /// Logout & go to sign in view
//    public func logout() {
//        self.userProfile.logout()
////        let vc = self.getStoryboardView(SignInViewController.self)
////        self.navigationController?.setViewControllers([vc], animated: true)
//    }
//}
}
