
import UIKit
import LocalAuthentication

class BaseViewController: ParentViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
  
//    func toNotificationVC() {
//        let vc = getStoryboardView(NotificationViewController.self)
//        self.navigationController?.pushViewController(vc, animated: true)
//        
//    }
//    
//    func logOut() {
//        self.userProfile.logout()
//        let vc = getStoryboardView(SignInViewController.self)
//        self.navigationController?.setViewControllers([vc], animated: true)
//
//    }
    
    // MARK: - faceID
    func faceID(_ complition: @escaping VoidCompletion){
        let context = LAContext()
        var error: NSError?
        
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "Identify yourself!"
            
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
                [weak self] success, authenticationError in
                
                DispatchQueue.main.async {
                    if success {
                        complition()
                    } else {
                        guard let self = self else { return }
                        let ac = UIAlertController(title: "authentication_failed_titel".localize(), message: "authentication_failed_messege".localize(), preferredStyle: .alert)
                        ac.addAction(UIAlertAction(title: "ok".localize(), style: .default))
                        self.present(ac, animated: true)
                    }
                }
            }
        } else {
            let ac = UIAlertController(title: "biometry_unavailable_titel".localize(), message: "biometry_unavailable_message".localize(), preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "ok".localize(), style: .default))
            self.present(ac, animated: true)
        }
    }
}

// MARK: - CUSTOM FUNCTIONS

extension BaseViewController {
    
    enum FilterModel: Int, CaseIterable {
        case new = 0
        case redy = 2
        case inDelivery = 3
        case done = 4
        
        var titel: String {
            switch self {
                
            case .new: return "new"
            case .redy: return "redy"
            case .inDelivery: return "in_delivery"
            case .done: return "done"
            }
        }
        
        var viewColor: UIColor {
            switch self {
                
            case .new: return UIColor.newFilter
            case .redy: return UIColor.readyFilter
            case .inDelivery: return UIColor.inDeliverFilter
            case .done: return UIColor.doneFilter
            }
        }
    }
    
    
    //    animateTable
    func animateTable(mytable : UITableView){
        mytable.reloadData()
        let cells = mytable.visibleCells
        let tableViewHeight = mytable.bounds.size.height
        for cell in cells{
            cell.transform = CGAffineTransform(translationX: 0, y: tableViewHeight)
        }
        var delayCounter = 0
        for cell in cells{
            
            UIView.animate(withDuration: 1.50, delay: Double(delayCounter) * 0.04, usingSpringWithDamping: 0.5, initialSpringVelocity: 0, options: .beginFromCurrentState, animations: {
                cell.transform = CGAffineTransform.identity
            }, completion: nil)
            delayCounter += 1
            
        }
    }
    
}
