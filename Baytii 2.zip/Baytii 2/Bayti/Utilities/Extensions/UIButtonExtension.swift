//
//  UIButtonExtension.swift
//  DukkanTogo
//
//  Created by Mohammed Hamad on 02/12/2021.
//

import Foundation
import UIKit

extension UIButton {
    
    @IBInspectable
    var isUpperCased: Bool {
        get { self.titleLabel?.text == self.titleLabel?.text?.uppercased() }
        set { self.setTitle(self.titleLabel?.text?.uppercased(), for: .normal) }
    }
    
    @IBInspectable
    var iconLocalizePadding: CGFloat {
        get {
            return 0
        }
        set {
            if LanguageManager.isRightToLeft(self) {
                self.imageEdgeInsets = UIEdgeInsets(top: 0, left: newValue, bottom: 0, right: 0)
            } else {
                self.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: newValue)
            }
        }
    }
}
