//
//  UIStoryboard.swift
//  ScanQR
//
//  Created by Dev. Mohmd on 7/3/20.
//  Copyright © 2020 Dev. Mohmd. All rights reserved.
//

import Foundation
import UIKit

extension UIStoryboard {
    
    static func getViewFromStoryboard(with identifier: String) -> UIViewController {
        
        let array = [
            UIStoryboard(name: "Main", bundle: nil),
            UIStoryboard(name: "AppScreen", bundle: nil),
        
        ]
        
        let dictionaryKey = "identifierToNibNameMap"
        
        for storyboard in array {
            guard let availableIdentifiers = storyboard.value(forKey: dictionaryKey) as? [String: Any],
                  availableIdentifiers[identifier] != nil else {
                continue
            }
            return storyboard.instantiateViewController(identifier: identifier)
        }
        fatalError("Storyboard \(identifier) not found")
    }
}
