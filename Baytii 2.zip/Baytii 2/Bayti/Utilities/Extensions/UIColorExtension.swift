//
//  UIImageViewExtension.swift
//  ScanQR
//
//  Created by Dev. Mohmd on 8/30/20.
//  Copyright © 2020 Dev. Mohmd. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    
//    static let mRed: UIColor = R.
//               bgGray: UIColor = R.color.bg_gray()!,
//               mLabelBlack: UIColor = R.color.label_black()!,
//               mRateYellow: UIColor = R.color.rate_yellow()!,
//               mWhite: UIColor = R.color.white()!
   
    
    static let praymaryColor = UIColor(named: "praimaryColor")!
    static let labelColor = UIColor(named: "black")!
    static let subViewColor = UIColor(named: "subViewColor")!
    static let grayColor = UIColor(named: "gray")!
    static let statusColor = UIColor(named: "statusColor")!
    static let red20 = UIColor(named: "red_color_20")!
    static let cardColor = UIColor(named: "CardColor")!
    static let delevard = UIColor(named: "delevard")!
    static let redColor = UIColor(named: "red_color")!
    static let newOrderColor = UIColor(named: "newOrderColor")!
    static let notDelevardColor = UIColor(named: "notDelevardColor")!
    
    static let readyFilter = UIColor(named: "readyFilter")!
    static let newFilter = UIColor(named: "newFilter")!
    static let inDeliverFilter = UIColor(named: "inDeliverFilter")!
    static let doneFilter = UIColor(named: "doneFilter")!

    
    public convenience init?(hex: String) {
        let r, g, b, a: CGFloat
        
        if hex.hasPrefix("#") {
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])
            
            if hexColor.count == 8 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0
                
                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff000000) >> 24) / 255
                    g = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    b = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    a = CGFloat(hexNumber & 0x000000ff) / 255
                    
                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
        }
        
        return nil
    }
    
    func colorWithHexString(hexString: String, alpha:CGFloat = 1.0) -> UIColor {
        
        // Convert hex string to an integer
        let hexint = Int(intFromHexString(hexStr: hexString))
        let red = CGFloat((hexint & 0xff0000) >> 16) / 255.0
        let green = CGFloat((hexint & 0xff00) >> 8) / 255.0
        let blue = CGFloat((hexint & 0xff) >> 0) / 255.0
        
        // Create color object, specifying alpha as well
        let color = UIColor(red: red, green: green, blue: blue, alpha: alpha)
        return color
    }
    func intFromHexString(hexStr: String) -> UInt32 {
        var hexInt: UInt32 = 0
        // Create scanner
        let scanner: Scanner = Scanner(string: hexStr)
        // Tell scanner to skip the # character
        scanner.charactersToBeSkipped = CharacterSet(charactersIn: "#")
        // Scan hex value
        scanner.scanHexInt32(&hexInt)
        return hexInt
    }
    
}
