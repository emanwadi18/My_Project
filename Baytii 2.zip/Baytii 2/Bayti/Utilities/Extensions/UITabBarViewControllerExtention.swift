//
//  UITabBarViewControllerExtention.swift
//  Shokr
//
//  Created by Ahmed Akram on 30/07/2022.
//

import Foundation
import UIKit

extension UITabBarController {
    
    func setupTabbarAppearance() {
        self.tabBar.tintColor = .black
        self.tabBar.unselectedItemTintColor = .gray
        self.tabBar.backgroundImage = UIImage()
        self.tabBar.barTintColor = UIColor.white
        self.tabBar.shadowImage = UIImage()
        
    }
    
    func setupTabbarShadow(){
        let layer = CAShapeLayer()
        layer.shadowColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.16)
        layer.shadowOffset = CGSize(width: 5.0, height: 5.0)
        layer.shadowRadius = 10.0
        layer.shadowOpacity = 0.5
    }
}
