//
//  HTMLParser.swift
//  Shokr
//
//  Created by Ahmed Akram on 24/07/2022.
//

//import Foundation
//import UIKit
//
//@objc extension NSString {
//    
//    class func parseHTMLString(stringHTML: String) -> NSString {
//        
//        return try! NSAttributedString(
//            data: stringHTML.data(using: String.Encoding.unicode, allowLossyConversion: true)!,
//            options: [ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType],
//            documentAttributes: nil).string as NSString
//    }
//    
//}
