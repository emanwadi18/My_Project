//
//  UIImageViewExtension.swift
//  ScanQR
//
//  Created by Dev. Mohmd on 8/30/20.
//  Copyright © 2020 Dev. Mohmd. All rights reserved.
//

import Foundation
import UIKit

extension UINavigationController {
    
    public func getPreviousView() -> UIViewController {
        let viewsInNavigation = self.viewControllers
        return viewsInNavigation[viewsInNavigation.count - 2]
    }
    
    public func popTo(_ viewClass: AnyClass, onFailure: VoidCompletion? = nil) {
        let check = checkViewIfExists(viewClass)
        if check.isExists {
            self.popToViewController(self.viewControllers[check.index], animated: true)
        } else {
            onFailure?()
        }
    }
    
    public func popToWithCompletion(_ viewClass: AnyClass, onFailure: VoidCompletion? = nil, animated: Bool, completion: @escaping () -> ()) {
        let check = checkViewIfExists(viewClass)
        if check.isExists {
            self.popToViewController(self.viewControllers[check.index], animated: true)
        } else {
            onFailure?()
        }
        if let coordinator = transitionCoordinator, animated {
            coordinator.animate(alongsideTransition: nil) { _ in
                completion()
            }
        } else {
            completion()
        }
    }
    
    public func popViewController(viewController: UIViewController? = nil,
                                  animated: Bool, completion: @escaping () -> ()) {
        if let viewController = viewController {
            popToViewController(viewController, animated: animated)
        } else {
            popViewController(animated: animated)
        }
        
        if let coordinator = transitionCoordinator, animated {
            coordinator.animate(alongsideTransition: nil) { _ in
                completion()
            }
        } else {
            completion()
        }
    }
    
    public func checkViewIfExists(_ viewClass: AnyClass) -> (isExists: Bool, index: Int) {
        for (index, controller) in self.viewControllers.enumerated() {
            if controller.isKind(of: viewClass) {
                return (true, index)
            }
        }
        return (false, -1)
    }
}

