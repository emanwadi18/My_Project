//
//  UIImageExtention.swift
//  AjnadeenCard
//
//  Created by Ahmed Akram on 20/08/2022.
//

import Foundation
import UIKit


extension UIImage {
    
    static let  paymentOption = UIImage(named: "ic_card_wilcome")!
    static let  featuredGifts = UIImage(named: "im_gift_wilcome")!
    static let  safePaymentMethod = UIImage(named: "ic_card_safe_wilcome")!
    static let  specialPrices = UIImage(named: "ic_$hand_wilcome")!
    static let failerAlirt = UIImage(named: "ic_error_alirt")!
    static let successAlirt = UIImage(named: "ic_success_alirt")!
    static let qrSend = UIImage(named: "ic_qr_send")!
    static let mobileSend = UIImage(named: "ic_mobile_send")!
    static let emailSend = UIImage(named: "ic_email_send")!
    static let acountSend = UIImage(named: "ic_acount_send")!
    static let unSelected = UIImage(named: "unSelected")!
    static let selected = UIImage(named: "selected")!
    static let charge = UIImage(named: "ic_charge")!
    static let sendIcone = UIImage(named: "send_icone")!
    static let chargeIcone = UIImage(named: "charge_icone")!
    static let resevIcone = UIImage(named: "ic_arow_request")!
    static let cardIcone = UIImage(named: "ic_card_tran")!
    static let defoltUserImage = UIImage(named: "ic_defolt_user")!
    static let virtifyImage = UIImage(named: "ic_verified")!
    static let notVirtifyImage = UIImage(named: "ic_not_verified")!
    // MARK: - sideMenu
    static let prsonalSide = UIImage(named: "ic_pirson_side")!
    static let favSide = UIImage(named: "ic_fav_side")!
    static let aboutUsSide = UIImage(named: "ic_about_side")!
    static let contactUs = UIImage(named: "ic_contact_side")!
    static let privacySide = UIImage(named: "ic_privac_side")!
    static let logoutSide = UIImage(named: "ic_logout_side")!
    static let cartSide = UIImage(named: "ic_cart_side")!
    static let notificationSide = UIImage(named: "ic_notification_side")!
    static let restorantSide = UIImage(named: "ic_restorant_side")!
    static let myOrders = UIImage(named: "ic_myOrderes_sideMenu")!
    
    // MARK: -  setting
    static let contact = UIImage(named: "ic_contact_setting")!
    static let faqs = UIImage(named: "ic_info_setting")!
    static let info = UIImage(named: "ic_infoo_setting")!
    static let language = UIImage(named: "ic_language_setting")!
    static let lock = UIImage(named: "ic_lock_setting")!
    static let rate = UIImage(named: "ic_rat_setting")!
    
    func addToCenter(of superView: UIView, width: CGFloat = 70, height: CGFloat = 70) {
        let overlayImageView = ImageViewDesign(image: self)
        
        overlayImageView.translatesAutoresizingMaskIntoConstraints = false
        overlayImageView.contentMode = .scaleAspectFit
        overlayImageView.backgroundColor = .praymaryColor
        overlayImageView.cornerRadius = 5
        overlayImageView.borderWidth = 2
        overlayImageView.borderColor = .white
        superView.addSubview(overlayImageView)
        
        let centerXConst = NSLayoutConstraint(item: overlayImageView, attribute: .centerX, relatedBy: .equal, toItem: superView, attribute: .centerX, multiplier: 1, constant: 0)
        let width = NSLayoutConstraint(item: overlayImageView, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 70)
        let height = NSLayoutConstraint(item: overlayImageView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 70)
        let centerYConst = NSLayoutConstraint(item: overlayImageView, attribute: .centerY, relatedBy: .equal, toItem: superView, attribute: .centerY, multiplier: 1, constant: 0)
        
        NSLayoutConstraint.activate([width, height, centerXConst, centerYConst])
    }
    
}
