//
//  UILabelExtension.swift
//  ScanQR
//
//  Created by Dev. Mohmd on 7/11/20.
//  Copyright © 2020 Dev. Mohmd. All rights reserved.
//

import Foundation
import UIKit

extension UILabel {
    
    @IBInspectable
    var isUpperCased: Bool {
        get { self.text == self.text?.uppercased() }
        set {
            if newValue {
                self.text = self.text?.uppercased()
            }
        }
    }
    
    public func setRegualAndBoldText(boldiText: String, regualText: String) {
        
        let attrs = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: font.pointSize)]
        let userString = NSMutableAttributedString(string: "User ")
        let boldiString = NSMutableAttributedString(string: boldiText, attributes:attrs)
        let regularString = NSMutableAttributedString(string: regualText)
        userString.append(boldiString)
        userString.append(regularString)
        attributedText = userString
   }
    
    func textDropShadow(color: UIColor? = nil) {
        self.layer.masksToBounds = false
        self.shadowColor = color ?? .gray
        self.layer.shadowRadius = 2.0
        self.layer.shadowOpacity = 0.8
        self.layer.shadowOffset = CGSize(width: 1, height: 2)
    }
    
    static func createCustomLabel() -> UILabel {
        let label = UILabel()
        label.textDropShadow()
        return label
    }
}
