
import Foundation
import UIKit

public enum InfoActionType: Int, CaseIterable {
    case edit = 0
    case save
    
    mutating func toggle() {
        switch self {
        case .edit: self = .save
        case .save: self = .edit
        }
    }
    
    var icon: UIImage? {
        get {
            switch self {
            case .edit: return .editActionImage
            case .save: return .saveActionImage
            }
        }
    }
    
    var textColor: UIColor {
        get {
            switch self {
            case .edit: return .systemGray2
            case .save: return .labelColor
            }
        }
    }
}
