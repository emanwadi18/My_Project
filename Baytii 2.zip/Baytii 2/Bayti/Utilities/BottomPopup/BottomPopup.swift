//
//  PopupView.swift
//  EMS
//
//  Created by Mohammed Hamad on 27/01/2022.
//

import UIKit

class BottomPopup: ViewDesign {
    
    private var parentView: UIView!
    
    init(parentView: UIView, isPanGesture: Bool = true) {
        super.init(frame: .zero)
        
        self.setupViews(parentView: parentView)
        self.setupTapGesture()
        if isPanGesture {
            self.setupPanGesture()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("Parent Bottom Popup init(coder:) has not been implemented")
    }
    
    private lazy var overlayView: UIView = {
        let overlay = UIView()
        overlay.isHidden = true
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        return overlay
    }()
    
    /// Set popup height from 0 to 1 to screen view (Default is 0.5)
    var heightPercentage: CGFloat = 0.6 {
        didSet {
            self.setupFrame()
        }
    }
    
    var widthPercentage: CGFloat = 1 {
        didSet {
            self.setupFrame()
        }
    }
    
    /// Set popup top left & right corner radius
    lazy var topCornersRadius: CGFloat = self.width / 16 {
        willSet {
            self.cornerRadius = newValue
        }
    }
    
    private var topPadding: CGFloat {
        get {
            return UIScreen.main.bounds.height * (1 - self.heightPercentage)
        }
    }
    
    private var maxHeight: CGFloat {
        get {
            return UIScreen.main.bounds.height * self.heightPercentage
        }
    }
    
    private var maxwidth: CGFloat {
        get {
            return UIScreen.main.bounds.width * self.widthPercentage
        }
    }
    
    func show(_ completion: VoidCompletion? = nil) {
        self.overlayView.isHidden = false
        self.isHidden = false
        
        animateView ({
            self.alpha = 1
            self.overlayView.alpha = 1
            self.frame.origin.y = self.topPadding
        }) {
            completion?()
        }
    }
    
    func hide(_ completion: VoidCompletion? = nil) {
        self.animateView({
            self.frame.origin.y = self.parentView.bottom
            self.overlayView.alpha = 0
            self.alpha = 0
        }) {
            self.overlayView.isHidden = true
            self.isHidden = true
            completion?()
        }
    }
}

// MARK: - CUSTOM FUNCTIONS

extension BottomPopup {
    
    private func setupViews(parentView: UIView) {
        self.parentView = parentView
        self.parentView.addSubview(self.overlayView)
        self.overlayView.frame = self.parentView.bounds
        self.parentView.addSubview(self)
        self.setupFrame()
        self.cornerRadius = self.topCornersRadius
        self.setViewCorners([.topLeft, .topRight])
        self.masksToBounds = true
    }
    
    private func setupTapGesture() {
        self.overlayView.addGestureRecognizer(
            UITapGestureRecognizer(target: self, action: #selector(self.didTapOverlayView(_:)))
        )
    }
    
    private func setupPanGesture() {
        self.addGestureRecognizer(
            UIPanGestureRecognizer(target: self, action: #selector(self.didPanView(_:)))
        )
    }
    
    private func setupFrame() {
        self.frame = CGRect(x: self.parentView.width / 2  - self.maxwidth / 2,
                            y: self.parentView.bottom,
                            width: self.maxwidth,
                            height: self.maxHeight)
    }
    
    private func animateView(_ animate: @escaping VoidCompletion, afterFinished: VoidCompletion? = nil) {
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            animate()
        }) { finished in
            if finished {
                afterFinished?()
            }
        }
    }
    
    @objc
    private func didTapOverlayView(_ gesture: UITapGestureRecognizer) {
        self.hide()
    }
    
    @objc
    private func didPanView(_ gesture: UIPanGestureRecognizer) {
        
        let translation = gesture.translation(in: self)
        
        switch gesture.state {
        case .changed:
            guard translation.y >= 0 else {
                self.transform = .identity
                return
            }
            self.transform = CGAffineTransform(translationX: 0, y: translation.y)
            
        case .ended:
            guard translation.y > (self.maxHeight * 0.35) else {
                self.animateView {
                    self.transform = .identity
                }
                return
            }
            self.animateView {
                self.transform = .identity
                self.hide()
            }
            
        default:
            break
        }
    }
}
