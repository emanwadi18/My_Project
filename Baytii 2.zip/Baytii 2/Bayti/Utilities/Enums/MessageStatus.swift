
import Foundation

enum MessageStatus {
    
    case Success
    case Warning
    case Error
}
