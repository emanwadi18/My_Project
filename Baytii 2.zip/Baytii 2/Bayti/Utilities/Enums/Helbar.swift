

import Foundation
import UIKit
//import GoogleSignIn
//import Alamofire

let isForDevelopment: Bool = true

// MARK:- Real Variables

public let cellInRows: CGFloat = 4.3

typealias ReloadCollectionClosure = ((CGFloat) -> Void)

//public let signInConfig = GIDConfiguration(clientID: "1053553505406-d693jn58as311v0otgsc5lebi6u35bf2.apps.googleusercontent.com")

public typealias VoidCompletion = (() -> Void)

public typealias UpdateClosure = (isSuccess: Bool, message: String)


struct Constants {
    
    private init() {}
    
    static let BASE_URL: String = "https://delawi-store.ormediaco.net"
    static let API_KEY_DEVICE_ID: String = "device_id"
    static let API_KEY_OS: String = "os"
    static let API_KEY_DEVICE_NAME = "device_name"
    
    /// return Device uuid string
    static let DEVICE_ID: String = UIDevice.current.identifierForVendor?.uuidString ?? ""
    
    /// return System name (IOS)
    static let OS_NAME: String = UIDevice.current.systemName
    
    
}

class LanguageManager {
    
    static func isRightToLeft(_ view: UIView) -> Bool {
        if #available(iOS 9.0, *) {
            return UIView.userInterfaceLayoutDirection(
                for: view.semanticContentAttribute) == .rightToLeft
        } else {
            return false
        }
    }
}
