

import UIKit

class MainNavigationViewController: UINavigationController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupView()
        localized()
        setupData()
        fetchData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationBar.isHidden = true
    }
}

extension MainNavigationViewController {
    
    func setupView() {
        AppDelegate.shared.rootNavigationController = self
        var vc = UIViewController()
        
        if userProfile.isFirstRun() {
        vc = self.getStoryboardView(OnboardingViews.self)
        }else {
            vc = self.getStoryboardView(SignInViewController.self)
        }
        self.setViewControllers([vc], animated: true)
//        
//        if LanguageManager.isRightToLeft(self.view) {
//            self.userProfile.changeIsRightToLeft()
//        }else {
//            self.userProfile.removeRtoL()
//        }
    }
    
    
    func localized() {
    }
    
    func setupData() {
    }
    
    func fetchData() {
    }
}

// MARK: - CUSTOM FUNCTIONS

extension MainNavigationViewController {
    
}
