

import UIKit

protocol NavigationBarViewDelegate: AnyObject {
    func didTabBack(_ view: NavigationBarView)
    func didTabCart(_ view: NavigationBarView)
    func didTabNotification(_ view: NavigationBarView)
}

class NavigationBarView: UIView {
    
    @IBOutlet weak var titelLabel: UILabel!
    @IBOutlet weak var cartCountLabel: UILabel!
    @IBOutlet weak var notificationCountLabel: UILabel!
    @IBOutlet weak var notificationCountView: ViewDesign!
    @IBOutlet weak var cartCountView: ViewDesign!
    @IBOutlet weak var cartView: UIView!
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var allNotificationView: ViewDesign!
    
    weak var delelgate: NavigationBarViewDelegate?
    
    var cartCount: String {
        get{
            self.cartCountView.isHidden = true
            return self.cartCountLabel.text ?? ""
        }
        set{
            self.cartCountView.isHidden = false
            self.cartCountLabel.text = newValue
        }
    }
    
    var notificationCount: String {
        get{
            self.notificationCountView.isHidden = true
            return self.notificationCountLabel.text ?? ""
        }
        set{
            self.notificationCountView.isHidden = false
            self.notificationCountLabel.text = newValue
        }
    }
    
    var titel: String? {
        get{
            return self.titelLabel.text ?? ""
        }
        set{
            self.titelLabel.text = newValue
        }
    }
    
  
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
        self.getCounts()
        self.addTabGesture()
        
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
        
        self.cartCountView.isHidden = true
        self.notificationCountView.isHidden = true
    }
    
    func getCounts(){
        guard let cartCount = userProfile.cartCount else {
            return

        }
        if cartCount > 0 {
        self.cartCount = "\(cartCount)"
        }else {
            self.cartCountView.isHidden = true
        }
        
        guard let notificationCount = userProfile.notificationCount else {
            return
            
        }
        if notificationCount > 0 {
        self.notificationCount = "\(notificationCount)"
        }else {
            self.notificationCountView.isHidden = true
        }
    }
    
    
    @IBAction func backAction(_ sender: Any) {
        self.delelgate?.didTabBack(self)
    }
    
    func addTabGesture(){
        let cartTab = UITapGestureRecognizer(target: self, action: #selector(self.cartAction(_:)))
        cartView.addGestureRecognizer(cartTab)
        
        let notificationTap = UITapGestureRecognizer(target: self, action: #selector(self.notificationAction(_:)))
        notificationView.addGestureRecognizer(notificationTap)
    }
    
    @objc func cartAction(_ sender: UITapGestureRecognizer? = nil) {
        self.delelgate?.didTabCart(self)
    }
    
    @objc func notificationAction(_ sender: UITapGestureRecognizer? = nil) {
        self.delelgate?.didTabNotification(self)
    }
}
