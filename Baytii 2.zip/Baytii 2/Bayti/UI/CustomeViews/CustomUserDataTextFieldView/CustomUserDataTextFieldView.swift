
import Foundation
import UIKit

class CustomUserDataTextFieldView: UIView {
    
    @IBOutlet weak var vertifyButton: UIButton!
    @IBOutlet weak private var containerViewDesign: ViewDesign!
    @IBOutlet weak var errorVlidationMassegLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var titelLabel: UILabel!
    @IBOutlet weak var textFieldCntenarView: ViewDesign!
    @IBOutlet weak private var iconButton: UIButton!
    @IBOutlet weak var starLabel: UILabel!
    
    
    var errorMasseg: String? {
        get {
            return errorVlidationMassegLabel.text ?? ""
        }
        set {
            self.errorVlidationMassegLabel.text = newValue?.localize()
        }
    }
    
    @IBInspectable
    var titel: String? {
        get { return self.titelLabel.text ?? "" }
        set { self.titelLabel.text = newValue?.localize() }
    }
    
    @IBInspectable
    var placeholder: String? {
        get { return self.textField.placeholder }
        set { self.textField.placeholder = newValue?.localize() }
    }
    
    @IBInspectable
    var icon: UIImage? {
        get { return self.iconButton.image(for: .normal) }
        set {
            self.iconButton.setImage(newValue, for: .normal)
        }
    }
    
    public weak var delegate: CustomUserDataTextFieldViewDelegate? {
        willSet {
            self.textField.returnKeyType = newValue!.returnKeyType(for: self)
            self.textField.keyboardType = newValue!.keyboardType?(for: self) ?? .default
            self.textField.isSecureTextEntry = newValue!.isSecureTextEntryFunc(for: self)
        }
    }
    
    /// Text Field text...
    var text: String {
        get {
            self.textField.text ?? ""
        }
        set {
            self.textField.text = newValue
        }
    }
    
    /// Text Field is enabled editing
    var isEnabled: Bool {
        get {
            return self.textField.isEnabled
        }
        set {
            self.textField.isEnabled = newValue
        }
    }
    
    var textFieldDelegate: CustomUserDataTextFieldDelegate?
    
    var configuration: Configuration = .default {
        didSet {
            self.setupConfiguration()
        }
    }
    
    struct Configuration {
        var isCircleCorner: Bool?
        var cornerRadius: CGFloat?
        var rectCorner: UIRectCorner?
        var borderWidth: CGFloat?
        var borderColor: UIColor?
        var textFieldTextColor: UIColor
        var titleLabelTextColor: UIColor
        var backgroundColor: UIColor
        var textFieldFont: UIFont
        var titleLabelFont: UIFont
        var shadow: CustomShadow?
        var isStar: Bool?
        var hideVirtifyButton: Bool
        
        static let `default`: Self = .init(cornerRadius: 6,
                                           textFieldTextColor: .black,
                                           titleLabelTextColor: UIColor.white,
                                           backgroundColor: UIColor.white,
                                           textFieldFont: .appFont(14),
                                           titleLabelFont: .appFont(14),
                                           shadow: nil,
                                           hideVirtifyButton: true)
        
        
        static let `userData`: Self = .init(cornerRadius: 6,
                                            borderWidth: 1,
                                            borderColor: .grayColor,
                                            textFieldTextColor: .black,
                                            titleLabelTextColor: UIColor.black,
                                            backgroundColor: UIColor.white,
                                            textFieldFont: .appFont(14),
                                            titleLabelFont: .appFont(14),
                                            shadow: nil,
                                            isStar: false,
                                            hideVirtifyButton: true)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
        self.textField.delegate = self
        self.setupConfiguration()
    }
    
    private func setupConfiguration() {
        let design = self.configuration
        
        self.containerViewDesign.layer.borderWidth = design.borderWidth ?? 0.0
        self.textFieldCntenarView.borderColor = design.borderColor ?? .clear
        
        self.containerViewDesign.backgroundColor = design.backgroundColor
        
        self.textField.textColor = design.textFieldTextColor
        self.titelLabel.textColor = design.titleLabelTextColor
        
        self.containerViewDesign.layer.borderColor = design.borderColor?.cgColor
        
        if design.isCircleCorner ?? false {
            self.containerViewDesign.isCircle = true
        } else {
            self.containerViewDesign.cornerRadius = design.cornerRadius ?? 0.0
        }
        if design.isStar == true {
            self.starLabel.isHidden = false
            
        }else {
            self.starLabel.isHidden = true
        }
        
        if design.hideVirtifyButton == true {
            self.vertifyButton.isHidden = true
        }else {
            self.vertifyButton.isHidden = false
        }
        
        self.containerViewDesign.setViewCorners(design.rectCorner ?? .allCorners)
        
        self.textField.font = design.textFieldFont
        //        self.titleLabel.font = design.titleLabelFont
        
        if let shadow = design.shadow {
            self.containerViewDesign.shadow = shadow
        }
    }
}

// MARK: - Actions

extension CustomUserDataTextFieldView {
    
    @IBAction func iconAction(_ sender: UIButton) {
        self.delegate?.didTapIcon?(for: self)
    }
    
    @IBAction func virtifyAction(_ sender: UIButton) {
        self.delegate?.didTapVertify?(for: self)
    }
    
    func setErrorWaringsIcon(validationHide:Bool , meesage: String = "") {
        let iconImage = UIImageView(frame: CGRect(x: 8, y: 5, width: 12, height: 12)) // set your Own size
        iconImage.image = UIImage(named: "ic_error_general")
        let iconContainerView: UIView = UIView(frame: CGRect(x: -10, y: -10, width: 18, height: 18))
        iconContainerView.backgroundColor = .clear
        iconContainerView.addSubview(iconImage)
        self.errorMasseg = meesage
        if LanguageManager.isRightToLeft(self){
            self.textField.rightView = iconContainerView
            self.textField.rightViewMode = .always
        }else{
            self.textField.leftView = iconContainerView
            self.textField.leftViewMode = .always
        }
        iconContainerView.isHidden = validationHide
        self.starLabel.isHidden = validationHide
        
        if validationHide {
            self.errorVlidationMassegLabel.textColor = .clear
        }else {
            self.errorVlidationMassegLabel.textColor = UIColor.red
        }
    }
}

// MARK: - Custom Functions

extension CustomUserDataTextFieldView {
    public func setFieldFirstReponser() {
        self.textField.becomeFirstResponder()
    }
}

// MARK: - Text Field Delegate

extension CustomUserDataTextFieldView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.textFieldDelegate?.textFieldDidBeginEditing?(textField, for: self)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.textFieldDelegate?.textFieldDidEndEditing?(textField, for: self)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return self.textFieldDelegate?.textFieldShouldReturn?(textField, for: self) ?? true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return self.textFieldDelegate?.textField?(textField, shouldChangeCharactersIn: range, replacementString: string, for: self) ?? true
    }
}

@objc
protocol CustomUserDataTextFieldViewDelegate: AnyObject {
    func returnKeyType(for view: CustomUserDataTextFieldView) -> UIReturnKeyType
    func isSecureTextEntryFunc(for view: CustomUserDataTextFieldView) -> Bool
    @objc optional func keyboardType(for view: CustomUserDataTextFieldView) -> UIKeyboardType
    @objc optional func didTapIcon(for view: CustomUserDataTextFieldView)
    @objc optional func didTapVertify(for view: CustomUserDataTextFieldView)
}

@objc
protocol CustomUserDataTextFieldDelegate: AnyObject {
    @objc optional func textFieldDidBeginEditing(_ textField: UITextField, for view: CustomUserDataTextFieldView)
    @objc optional func textFieldDidEndEditing(_ textField: UITextField, for view: CustomUserDataTextFieldView)
    @objc optional func textFieldShouldReturn(_ textField: UITextField, for view: CustomUserDataTextFieldView) -> Bool
    @objc optional func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String, for view: CustomUserDataTextFieldView) -> Bool
}
