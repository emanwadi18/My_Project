

import UIKit
import Cosmos

class RateView: UIView {
    
    @IBOutlet weak private var cosmosView: CosmosView!
    
    @IBInspectable
    var starSize: Double {
        get { return self.settings.starSize }
        set { self.settings.starSize = newValue }
    }
    
    @IBInspectable
    var starMargin: Double {
        get { return self.settings.starMargin }
        set { self.settings.starMargin = newValue }
    }
    
    @IBInspectable
    var emptyBorderWidth: Double {
        get { return self.settings.emptyBorderWidth }
        set { self.settings.emptyBorderWidth = newValue }
    }
    
    @IBInspectable
    var emptyBorderColor: UIColor {
        get { return self.settings.emptyBorderColor }
        set { self.settings.emptyBorderColor = newValue }
    }
    
    @IBInspectable
    var filledColor: UIColor {
        get { return self.settings.filledColor }
        set { self.settings.filledColor = newValue }
    }
    
    @IBInspectable
    var updateOnTouch: Bool {
        get { return self.settings.updateOnTouch }
        set { self.settings.updateOnTouch = newValue }
    }
    
    var settings: CosmosSettings {
        get {
            return self.cosmosView.settings
        }
        set {
            self.cosmosView.settings = newValue
        }
    }
    
    var rate: Double {
        get {
            return cosmosView.rating
        }
        set {
            self.cosmosView.rating = newValue
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
        
        self.cosmosView.rating = 0
    }
}
