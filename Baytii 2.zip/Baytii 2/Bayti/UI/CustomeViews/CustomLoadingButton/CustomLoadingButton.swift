
//
import Foundation
import UIKit

protocol CustomLoadingButtonDelegate: AnyObject {
    func didTouchUpInside(_ button: CustomLoadingButton)
}

class CustomLoadingButton: UIView {
    
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var titleStackView: UIStackView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBInspectable
    var isUpperCased: Bool {
        get {
            return self.titleLabel.isUpperCased
        }
        set {
            self.titleLabel.isUpperCased = newValue
        }
    }
    
    @IBInspectable
    var title: String {
        get {
            return self.titleLabel.text ?? ""
        }
        set {
            self.titleLabel.text = newValue
        }
    }
    
    weak var delegate: CustomLoadingButtonDelegate?
    
    /// Replace title with loading indicator
    var isLoading: Bool = false {
        willSet {
            self.titleStackView.isHidden = newValue
            if !newValue {
                self.loadingIndicator.stopAnimating()
            } else {
                self.loadingIndicator.startAnimating()
            }
        }
    }
    
    var configuration: Configuration = .default {
        didSet {
            self.changeConfiguration()
        }
    }
    
    struct Configuration {
        var titleFont: UIFont
        
        static let `default`: Self = .init(titleFont: .appFont(14))
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
    }
}

// MARK: - ACTIONS

extension CustomLoadingButton {
    
    @IBAction func buttonAction(_ sender: UIButton) {
        guard !self.isLoading else { return }
        self.delegate?.didTouchUpInside(self)
    }
}

// MARK: - CUSTOM FUNCTIONS

extension CustomLoadingButton {
    
    private func changeConfiguration() {
        self.titleLabel.font = self.configuration.titleFont
    }
}
