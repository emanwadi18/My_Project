

import Foundation
import UIKit
import SwiftUI

class CustomTextFieldView: UIView {
    
    
    @IBOutlet weak private var containerViewDesign: ViewDesign!
    @IBOutlet weak var errorVlidationMassegLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textFieldCntenarView: ViewDesign!
    @IBOutlet weak private var iconButton: UIButton!
    @IBOutlet weak var eyeButton: UIButton!
    
    
    
    var errorMasseg: String? {
        get {
            return errorVlidationMassegLabel.text ?? ""
        }
        set {
            self.errorVlidationMassegLabel.text = newValue?.localize()
        }
    }
    
    
    
    @IBInspectable
    var placeholder: String? {
        get { return self.textField.placeholder }
        
        set {let attributes = [NSAttributedString.Key.foregroundColor: UIColor.grayColor,
                               .font: UIFont.systemFont(ofSize: 12)]
            
            textField.attributedPlaceholder = NSAttributedString(string: newValue!.localize(),
                                                                 attributes: attributes) }
    }
    
    @IBInspectable
    var icon: UIImage? {
        get { return self.iconButton.image(for: .normal) }
        set {
            self.iconButton.setImage(newValue, for: .normal)
        }
    }
    
    public weak var delegate: CustomTextFieldViewDelegate? {
        willSet {
            self.textField.returnKeyType = newValue!.returnKeyType(for: self)
            self.textField.keyboardType = newValue!.keyboardType?(for: self) ?? .default
            self.textField.isSecureTextEntry = newValue!.isSecureTextEntryFunc(for: self)
        }
    }
    
    /// Text Field text...
    var text: String {
        get {
            self.textField.text ?? ""
        }
        set {
            self.textField.text = newValue
        }
    }
    
    /// Text Field is enabled editing
    var isEnabled: Bool {
        get {
            return self.textField.isEnabled
        }
        set {
            self.textField.isEnabled = newValue
        }
    }
    
    var textFieldDelegate: CustomTextFieldDelegate?
    
    var configuration: Configuration = .default {
        didSet {
            self.setupConfiguration()
        }
    }
    
    struct Configuration {
        var isCircleCorner: Bool?
        var cornerRadius: CGFloat?
        var rectCorner: UIRectCorner?
        var borderWidth: CGFloat?
        var borderColor: UIColor?
        var textFieldTextColor: UIColor
        var backgroundColor: UIColor
        var textFieldFont: UIFont
        var titleLabelFont: UIFont
        var shadow: CustomShadow?
        var isStar: Bool?
        var hideEyeButton: Bool
        
        static let `default`: Self = .init(cornerRadius: 6,
                                           borderColor:UIColor.grayColor,
                                           textFieldTextColor: .black,
                                           backgroundColor: UIColor.white,
                                           textFieldFont: .appFont(14),
                                           titleLabelFont: .appFont(14),
                                           shadow: nil,
                                           hideEyeButton: true)
        
        
        static let `userData`: Self = .init(cornerRadius: 6,
                                            borderWidth: 1,
                                            borderColor: .praymaryColor,
                                            textFieldTextColor: .black,
                                            backgroundColor: UIColor.white,
                                            textFieldFont: .appFont(14),
                                            titleLabelFont: .appFont(14),
                                            shadow: nil,
                                            isStar: false,
                                            hideEyeButton: true)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
        self.textField.delegate = self
        self.setupConfiguration()
    }
    
    private func setupConfiguration() {
        let design = self.configuration
        
        
        
        self.containerViewDesign.layer.borderWidth = design.borderWidth ?? 0.0
        self.textFieldCntenarView.borderColor = design.borderColor ?? .clear
        
        self.containerViewDesign.backgroundColor = design.backgroundColor
        
        self.textField.textColor = design.textFieldTextColor
        
        self.containerViewDesign.layer.borderColor = design.borderColor?.cgColor
        
        if design.isCircleCorner ?? false {
            self.containerViewDesign.isCircle = true
        } else {
            self.containerViewDesign.cornerRadius = design.cornerRadius ?? 0.0
        }
        
        if design.hideEyeButton {
            self.eyeButton.isHidden = true
        }else {
            self.eyeButton.isHidden = false
        }
        
        
        self.containerViewDesign.setViewCorners(design.rectCorner ?? .allCorners)
        
        self.textField.font = design.textFieldFont
        //        self.titleLabel.font = design.titleLabelFont
        
        if let shadow = design.shadow {
            self.containerViewDesign.shadow = shadow
        }
    }
}

// MARK: - Actions

extension CustomTextFieldView {
    
    @IBAction func iconAction(_ sender: UIButton) {
        self.delegate?.didTapIcon?(for: self)
    }
    
    func setErrorWaringsIcon(validationHide:Bool , meesage: String = "") {
        let iconImage = UIImageView(frame: CGRect(x: 8, y: 5, width: 12, height: 12)) // set your Own size
        iconImage.image = UIImage(named: "ic_error_general")
        let iconContainerView: UIView = UIView(frame: CGRect(x: -10, y: -10, width: 18, height: 18))
        iconContainerView.backgroundColor = .clear
        iconContainerView.addSubview(iconImage)
        self.errorMasseg = meesage
        if LanguageManager.isRightToLeft(self){
            self.textField.rightView = iconContainerView
            self.textField.rightViewMode = .always
        }else{
            self.textField.leftView = iconContainerView
            self.textField.leftViewMode = .always
        }
        iconContainerView.isHidden = validationHide
        
        if validationHide {
            self.errorVlidationMassegLabel.textColor = .clear
        }else {
            self.errorVlidationMassegLabel.textColor = UIColor.red
        }
    }
}

// MARK: - Custom Functions

extension CustomTextFieldView {
    public func setFieldFirstReponser() {
        self.textField.becomeFirstResponder()
    }
}

// MARK: - Text Field Delegate

extension CustomTextFieldView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.textFieldDelegate?.textFieldDidBeginEditing?(textField, for: self)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.textFieldDelegate?.textFieldDidEndEditing?(textField, for: self)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return self.textFieldDelegate?.textFieldShouldReturn?(textField, for: self) ?? true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return self.textFieldDelegate?.textField?(textField, shouldChangeCharactersIn: range, replacementString: string, for: self) ?? true
    }
}

@objc
protocol CustomTextFieldViewDelegate: AnyObject {
    func returnKeyType(for view: CustomTextFieldView) -> UIReturnKeyType
    func isSecureTextEntryFunc(for view: CustomTextFieldView) -> Bool
    @objc optional func keyboardType(for view: CustomTextFieldView) -> UIKeyboardType
    @objc optional func didTapIcon(for view: CustomTextFieldView)
    @objc optional func didTapVertify(for view: CustomTextFieldView)
}

@objc
protocol CustomTextFieldDelegate: AnyObject {
    @objc optional func textFieldDidBeginEditing(_ textField: UITextField, for view: CustomTextFieldView)
    @objc optional func textFieldDidEndEditing(_ textField: UITextField, for view: CustomTextFieldView)
    @objc optional func textFieldShouldReturn(_ textField: UITextField, for view: CustomTextFieldView) -> Bool
    @objc optional func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String, for view: CustomTextFieldView) -> Bool
}
