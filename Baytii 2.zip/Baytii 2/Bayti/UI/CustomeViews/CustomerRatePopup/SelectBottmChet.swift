

import UIKit

//protocol SelectBottmChetDelegate: AnyObject {
//    func didTabAdress(_ popup: SelectBottmChet , _ address: Contry, _ stataus:SelectBottmChet.DataStatus )
//}
//
//class SelectBottmChet: BottomPopup {
//    
//    @IBOutlet weak var tabelView: UITableView!
//    @IBOutlet weak var serchTextField: UITextField!
//    @IBOutlet weak var titelLabel: UILabel!
//    @IBOutlet weak var textFieldView: ViewDesign!
//    
//    enum DataStatus {
//        case contry
//        case cictys
//    }
//    
//    var status: DataStatus = .contry
//    weak var delegate: SelectBottmChetDelegate?
//    
//    var contry: [Contry]? {
//        willSet {
//            self.tabelView.reloadData()
//        }
//    }
//    var cictes: [Contry]? {
//        willSet {
//            self.tabelView.reloadData()
//        }
//    }
//    
//    
//    private lazy var loadingView:  LoadingView = {
//        return LoadingView(parentView: self)
//    }()
//    
//    var selectedAdress: Contry? {
//        willSet {
//            self.tabelView.reloadData()
//            guard let data = newValue else { return }
//            self.serchTextField.text = data._name
//            self.textFieldView.layer.borderColor = UIColor.praymaryColor.cgColor
//            self.serchTextField.textColor = UIColor.praymaryColor
//        }
//    }
//    
//    
//    override init(parentView: UIView, isPanGesture: Bool = true) {
//        super.init(parentView: parentView, isPanGesture: isPanGesture)
//        
//        self.setupView()
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("Customer Rate Popup init(coder:) has not been implemented")
//    }
//    
//    private func setupView() {
//        guard let view = self.loadViewFromNib() else { return }
//        self.addSubview(view)
//        view.frame = self.bounds
//       
//        self.heightPercentage  = 0.6
//        self.serchTextField.isUserInteractionEnabled = false
//        self.tabelView.delegate = self
//        self.tabelView.dataSource = self
//        self.tabelView.registerNib(LabelWithCheckBoxTableViewCell.self)
//    }
//    
//}
//
//
//// MARK: - CUSTOM FUNCTIONS
//
//extension SelectBottmChet {
//    
//    @IBAction func cancelAction(_ sender: UIButton){
//        self.serchTextField.text = ""
//    }
//}
//
//extension SelectBottmChet: UITableViewDelegate , UITableViewDataSource {
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        switch self.status {
//            
//        case .contry:
//            return contry?.count ?? 0
//        case .cictys:
//            return cictes?.count ?? 0
//        }
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueCell(LabelWithCheckBoxTableViewCell.self, for: indexPath)
//        switch self.status {
//            
//        case .contry:
//            if let object = contry?[indexPath.row] {
//                cell.cellLabel.text = object._name
//                cell.isCellSelected = self.selectedAdress == object
//            }
//        case .cictys:
//            if let object = cictes?[indexPath.row] {
//                cell.cellLabel.text = "\(object._name) \("(\(object._price)Lyd)")"
//                cell.isCellSelected = self.selectedAdress == object
//            }
//        }
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        
//        switch self.status {
//            
//        case .contry:
//            let object = contry?[indexPath.row]
//            self.selectedAdress = object
//            guard let object = object else { return }
//            self.delegate?.didTabAdress(self, object, self.status)
//        case .cictys:
//            let object = cictes?[indexPath.row]
//            self.selectedAdress = object
//            guard let object = object else { return }
//            self.delegate?.didTabAdress(self, object, self.status)
//        }
//        
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 40
//    }
//    
//}
