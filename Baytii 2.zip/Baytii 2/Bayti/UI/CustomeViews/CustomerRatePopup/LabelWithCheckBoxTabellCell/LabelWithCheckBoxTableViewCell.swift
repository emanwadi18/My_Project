//
//  LabelWithCheckBoxTableViewCell.swift
//  AjnadeenCard
//
//  Created by Ahmed Akram on 17/09/2022.
//

import UIKit

class LabelWithCheckBoxTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cellLabel: UILabel!
    @IBOutlet weak var cellCheckBoxImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    var isCellSelected: Bool = false {
        willSet {
            self.cellCheckBoxImageView.image = newValue ? UIImage.selected : UIImage.unSelected
        }
    }
    
}
