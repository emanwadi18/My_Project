

import Foundation
import UIKit

protocol CustomDatePickerViewDelegate: AnyObject {
    func didSelect(_ datePickerView: CustomDatePickerView, date: Date, for format: String)
}

class CustomDatePickerView: UIView {
    
    @IBOutlet weak var containerViewDesign: ViewDesign!
    
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var iconButton: UIButton!
    
    var doneBtn = UIBarButtonItem()
    
    
    private lazy var datePicker: UIDatePicker = {
        let picker = UIDatePicker()
        if #available(iOS 13.4, *) {
            picker.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        return picker
    }()
    
    
    
    @IBInspectable
    var placeholder: String {
        get {
            return self.textField.placeholder ?? ""
        }
        set {
            self.textField.placeholder = newValue
        }
    }
    
    @IBInspectable
    var icon: UIImage? {
        get { return self.iconButton.image(for: .normal) }
        set {
            self.iconButton.isHidden = false
            self.iconButton.setImage(newValue, for: .normal)
        }
    }
    
    weak var delegate: CustomDatePickerViewDelegate?
    
    /// Date String
    var dateString: String {
        get {
            return self.textField.text ?? ""
        }
        set {
            self.textField.text = newValue
        }
    }
    
    /// Date Object
    var date: Date {
        get {
            return self.datePicker.date
        }
        set {
            self.datePicker.date = newValue
            self.dateString = newValue.formatDate(self.fieldFormat)
            
            //            switch self.configuration.type {
            //            case .date:
            //                break
            //            case .time:
            //                break
            //            }
        }
    }
    
    private(set) var fieldFormat: String = ""
    
    enum FieldType {
        case date(String)
        case time
    }
    
    var configuration: Configuration = .default {
        didSet {
            self.changeConfiguration()
        }
    }
    
    struct Configuration {
        var isTitleHidden: Bool
        var type: FieldType
        var titleColor: UIColor
        var titleFont: UIFont
        var textColor: UIColor
        var textFont: UIFont
        var iconColor: UIColor
        var icon: UIImage?
        var backgroundColor: UIColor
        var shadow: CustomShadow?
        var timeZone: TimeZone
        var locale: Locale
        
        static let `default`: Self = .init(isTitleHidden: true,
                                           type: .date("dd/MM/yyyy"),
                                           titleColor: .black,
                                           titleFont: .systemFont(ofSize: 14),
                                           textColor: .black,
                                           textFont: .systemFont(ofSize: 16),
                                           iconColor: .black,
                                           icon: UIImage(systemName: "calendar"),
                                           backgroundColor: .clear,
                                           shadow: nil,
                                           timeZone: .current,
                                           locale: .current)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
        self.doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.dateDonePressed))
        self.datePicker.addTarget(self, action: #selector(handleDatePicker), for: .valueChanged)
        
        self.changeConfiguration()
        
    }
    
    private func changeConfiguration() {
        let config = self.configuration
        
        self.datePicker.locale = config.locale
        self.datePicker.timeZone = config.timeZone
        
        
        
        self.textField.textColor = config.textColor
        self.textField.font = config.textFont
        
        self.iconButton.tintColor = config.iconColor
        self.iconButton.setImage(config.icon, for: .normal)
        
        self.containerViewDesign.shadow = config.shadow
        
        self.createDatePicker(by: config.type)
    }
    
    @objc func handleDatePicker(_ datePicker: UIDatePicker) {
        self.doneBtn.isEnabled = datePicker.date > Date()
    }
}

// MARK: - ACTIONS

extension CustomDatePickerView {
    
    @IBAction func dateIconAction(_ sender: UIButton) {
        self.showDatePicker()
    }
}

// MARK: - CUSTOM FUNCTIONS

extension CustomDatePickerView {
    
    public func showDatePicker() {
        self.textField.becomeFirstResponder()
    }
    
    private func createDatePicker(by type: FieldType) {
        switch type {
        case .date(let format):
            self.fieldFormat = format
            self.datePicker.datePickerMode = .date
            break
        case .time:
            self.fieldFormat = "hh:mm a"
            self.datePicker.datePickerMode = .time
            break
        }
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let centerSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelBtn = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(self.dateCancelPressed))
        toolbar.setItems([cancelBtn, centerSpace,doneBtn], animated: true)
        
        self.textField.inputAccessoryView = toolbar
        self.textField.inputView = self.datePicker
    }
    
    @objc private func dateDonePressed() {
        let dateString = self.formatDate(self.datePicker.date)
        self.textField.text = dateString
        self.delegate?.didSelect(self, date: self.datePicker.date, for: self.fieldFormat)
        self.dateCancelPressed()
    }
    
    @objc private func dateCancelPressed() {
        self.endEditing(true)
    }
    
    private func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = self.fieldFormat
        dateFormatter.timeZone = self.configuration.timeZone
        return dateFormatter.string(from: date)
    }
    
    
    
}
