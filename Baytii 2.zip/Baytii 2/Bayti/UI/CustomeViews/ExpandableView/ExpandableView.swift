

import UIKit

class ExpandableView: UIView {
    
    
    @IBOutlet weak private var containerStackView: UIStackView!
    
    @IBOutlet weak private var containerViewDesign: ViewDesign!
    
    @IBOutlet weak private var separatorStackView: UIStackView!
    
    @IBOutlet weak private var titleLabel: UILabel!
    
    @IBOutlet weak private var arrowImageView: UIImageView!
    
    /// Title of view ...
    @IBInspectable var title: String {
        get {
            return self.titleLabel.text ?? ""
        }
        set {
            self.titleLabel.text = newValue
        }
    }
    
    var isOpened: Bool = false {
        willSet {
            self.arrowDirection = newValue ? .up : .down
            self.containerCorners = newValue ? [.topLeft, .topRight] : .allCorners
            let bottomMargin: CGFloat = newValue ? 0 : 8
            self.containerStackInsets = UIEdgeInsets(top: 0, left: 8, bottom: bottomMargin, right: 8)
            self.separatorStackView.isHidden = !newValue
            self.containerViewDesign.layer.borderColor = newValue ? UIColor.praymaryColor.cgColor : UIColor.lightGray.cgColor
        }
    }
    
    var configuration: Configuration = .default {
        didSet {
            self.setupConfiguration()
        }
    }
    
    private var containerCorners: UIRectCorner = .allCorners {
        willSet {
            self.containerViewDesign.setViewCorners(newValue)
        }
    }
    
    private var containerStackInsets: UIEdgeInsets = .zero {
        willSet {
            self.containerStackView.isLayoutMarginsRelativeArrangement = true
            self.containerStackView.layoutMargins = newValue
        }
    }
    
    private var arrowDirection: ArrowDirection = .down {
        willSet {
            self.rotateArrow(to: newValue)
        }
    }
    
    struct Configuration {
        var arrowTintColor: UIColor
        var titleColor: UIColor
        var titleFont: UIFont
        var backgroundColor: UIColor
        var isHasIcon: Bool
        var borderColor: UIColor
        var borderWidth: CGFloat
        
        static let `default`: Self = .init(arrowTintColor: UIColor.black,
                                           titleColor: UIColor.black,
                                           titleFont: UIFont.appFont(14).bold,
                                           backgroundColor: .white,
                                           isHasIcon: false,
                                           borderColor: UIColor.lightGray,
                                           borderWidth: 1
        )
    }
    
    enum ArrowDirection: Int, CaseIterable {
        case up = 0
        case down
        
        mutating func toggle() {
            switch self {
            case .down: self = .up
            case .up: self = .down
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
        
        self.setupConfiguration()
    }
    
    private func setupConfiguration() {
        self.arrowImageView.tintColor = self.configuration.arrowTintColor
        self.titleLabel.textColor = self.configuration.titleColor
        self.titleLabel.font = self.configuration.titleFont
        self.containerViewDesign.backgroundColor = self.configuration.backgroundColor
        self.containerViewDesign.layer.borderWidth = self.configuration.borderWidth
        self.containerViewDesign.layer.borderColor = self.configuration.borderColor.cgColor
    }
    
    private func rotateArrow(to direction: ArrowDirection) {
        self.arrowImageView.transform = direction == .down ? .identity : CGAffineTransform(rotationAngle: .pi)
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
            self.layoutIfNeeded()
        }
    }
}
