
import Foundation
import UIKit

class CustomCheckBoxView: UIView {
    
    @IBOutlet weak private var iconImageView: UIImageView!
    
    @IBOutlet weak private var titleLabel: UILabel!
    
    @IBOutlet weak private var selectedViewDesign: ViewDesign!
    
    @IBInspectable
    var title: String {
        get {
            self.titleLabel.text ?? ""
        }
        set {
            self.titleLabel.text = newValue
        }
    }
    
    var icon: UIImage? {
        get {
            self.iconImageView.image
        }
        set {
            self.iconImageView.image = newValue
        }
    }
    
//    var imageURL: String = "" {
//        willSet {
//            self.iconImageView.kf.setImage(with: URL(string: newValue))
//        }
//    }
    
    var isSelected: Bool = false {
        willSet {
            self.selectedViewDesign.borderWidth = newValue ? 5 : 1
            self.selectedViewDesign.borderColor = newValue ? .red : .black
            self.selectedViewDesign.layoutSubviews()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        self.setupView()
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
    }
}
