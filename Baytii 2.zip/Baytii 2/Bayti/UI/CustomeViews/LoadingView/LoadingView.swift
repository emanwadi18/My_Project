

import Foundation
import UIKit
import Lottie

class LoadingView: ViewDesign {
    
    
    @IBOutlet weak var animationView: AnimationView!
    
    private var parentView: UIView!
    
    init(parentView: UIView) {
        super.init(frame: .zero)
        
        self.parentView = parentView
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
    }
    
    private func setupView() {
        guard let view = self.loadViewFromNib() else { return }
        self.addSubview(view)
        view.frame = self.bounds
    }
    
    func startloading() {
        self.parentView.addSubview(self)
        self.frame = parentView.bounds
        setupLotte()
       
    }
    
    func stopLoading() {
        self.removeFromSuperview()
    }
    
    func setupLotte() {
        self.animationView.animation = Animation.named("97241-loading-animation.json")
        animationView.animationSpeed = 1.5
        self.animationView.loopMode = .loop
        self.animationView.play()
    }
}
