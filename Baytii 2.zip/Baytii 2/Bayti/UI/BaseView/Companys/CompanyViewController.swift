

import UIKit
struct CompanyModel {
    var image: UIImage?
    var name: String?
    var details: String?
    var rate: Double?
}


class CompanyViewController: UIViewController {
    
    
    
    @IBOutlet weak var tabelView: UITableView!
    
    var data = [CompanyModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        fetchData()
        self.tabelView.delegate = self
        self.tabelView.dataSource = self
        self.tabelView.registerNib(CompanTableViewCell.self)
    }
    
    
    func fetchData() {
        self.data = [
            CompanyModel(image: UIImage(named: "logo 1"), name: "المقاولون", details: "دبي", rate: 2.5),
            CompanyModel(image: UIImage(named: "logo 2"), name: "العقارات", details: "دبي", rate: 3.0),
            CompanyModel(image: UIImage(named: "logo 3"), name: "الهدى", details: "دبي", rate: 5.0)
        ]
    }
    
}
extension CompanyViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueCell(CompanTableViewCell.self, for: indexPath)
        let object = self.data[indexPath.row]
        cell.object = object
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = self.getStoryboardView(CompanyDetailsViewController.self)
        let object = self.data[indexPath.row]
        vc.data = object
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

