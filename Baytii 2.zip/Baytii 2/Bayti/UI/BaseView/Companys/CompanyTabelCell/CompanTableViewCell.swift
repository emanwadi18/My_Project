

import UIKit

class CompanTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var adressLabel: UILabel!
    @IBOutlet weak var rateView: RateView!
    @IBOutlet weak var cellImageView: ImageViewDesign!
    
    var object : CompanyModel? {
        willSet {
            guard let object = newValue else { return }
            self.cellImageView.image = object.image
            self.nameLabel.text = object.name
            self.adressLabel.text = object.details
            self.rateView.rate = object.rate ?? 0.0
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
