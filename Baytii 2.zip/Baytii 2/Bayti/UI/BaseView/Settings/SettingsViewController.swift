

import UIKit

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var tabelView: UITableView!
    
    enum Settings: String, CaseIterable {
        case profile
        case about
        case TermsConditions
        case logout
        
        var title: String {
            get {
                switch self {
                    
                case .profile: return "الملف الشخصي"
                case .about: return "عن التطبيق"
                case .TermsConditions: return "الشروط ةالاحكام"
                case .logout: return "تسجيل الخروج"
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupView()
    }
    
    func setupView() {
        self.tabelView.dataSource = self
        self.tabelView.delegate = self
        self.tabelView.registerNib(SettingTableViewCell.self)
    }
    
    
}
extension SettingsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Settings.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueCell(SettingTableViewCell.self, for: indexPath)
        let object = Settings.allCases[indexPath.row]
        cell.cellTitelLabel.text = object.title
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let object = Settings.allCases[indexPath.row]
        switch object {
            
        case .profile: break
        case .about: break
        case .TermsConditions: break
        case .logout:
            let vc = self.getStoryboardView(SignInViewController.self)
            self.navigationController?.setViewControllers([vc], animated: true)
            break
        }
        
    }
    
    
}


