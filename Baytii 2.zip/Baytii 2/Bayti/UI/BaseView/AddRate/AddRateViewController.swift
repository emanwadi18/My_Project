//
//  AddRateViewController.swift
//  Bayti
//
//  Created by Ahmed Akram on 18/12/2022.
//

import UIKit

class AddRateViewController: UIViewController {
    @IBOutlet weak var rateView: RateView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        rateView.isUserInteractionEnabled = true

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
