//
//  CompanyDetailsViewController.swift
//  Bayti
//
//  Created by Ahmed Akram on 18/12/2022.
//

import UIKit

class CompanyDetailsViewController: UIViewController {

    @IBOutlet weak var backTitelButton: UIButton!
    
    @IBOutlet weak var rateView: RateView!
    @IBOutlet weak var companyImageView: ImageViewDesign!
    @IBOutlet weak var companyTypeLabel: UILabel!
    var data: CompanyModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        guard let data = self.data else { return }
        self.backTitelButton.setTitle(data.name, for: .normal)
        self.companyImageView.image = data.image
        self.companyTypeLabel.text = data.details
        self.rateView.rate = data.rate ?? 0.0
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func addRateAction(_ sender: Any) {
        let vc = self.getStoryboardView(AddRateViewController.self)
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func showRatesAction(_ sender: Any) {
        let vc = self.getStoryboardView(CompanyRateViewController.self)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
