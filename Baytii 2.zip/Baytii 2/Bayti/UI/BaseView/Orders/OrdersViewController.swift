
import UIKit

struct orderModel {
    var image: UIImage?
    var name: String?
    var details: String?
    var price: String?
}

class OrdersViewController: UIViewController {
    
    
    @IBOutlet weak var tabelView: UITableView!
    
    var data = [orderModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        fetchData()
        self.tabelView.delegate = self
        self.tabelView.dataSource = self
        self.tabelView.registerNib(OrderTableViewCell.self)
    }
    
    
    func fetchData() {
        self.data = [
            orderModel(image: UIImage(named: "im 1"), name: "شقة", details: "شقة شقة", price: "3000 درهم"),
            orderModel(image: UIImage(named: "im 2"), name: "فيلا", details: "فيلا فيلا", price: "3000 درهم"),
            orderModel(image: UIImage(named: "im 3"), name: "شقة", details: "شقة شقة", price: "3000 درهم")
        ]
    }
    
    @IBAction func addAction(_ sender: UIButton) {
        let vc = self.getStoryboardView(AddOrderViewController.self)
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
extension OrdersViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueCell(OrderTableViewCell.self, for: indexPath)
        let object = self.data[indexPath.row]
        cell.object = object
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let object = self.data[indexPath.row]
        let vc = self.getStoryboardView(OrderDetailsViewController.self)
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
}
extension OrdersViewController : AddOrderViewControllerDelegate{
    

func addOrder(order: orderModel) {
 
    self.data.append(order)
    self.tabelView.reloadData()
}

}
