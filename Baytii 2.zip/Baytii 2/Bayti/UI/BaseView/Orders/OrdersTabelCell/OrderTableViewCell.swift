//
//  OrderTableViewCell.swift
//  Bayti
//
//  Created by Ahmed Akram on 17/12/2022.
//

import UIKit

class OrderTableViewCell: UITableViewCell {

    @IBOutlet weak var cellImageView: UIImageView!
    @IBOutlet weak var orderNameLabel: UILabel!
    @IBOutlet weak var orderDetailsLabel: UILabel!
    @IBOutlet weak var orderPriceLabel: UILabel!
    
    var object: orderModel? {
        willSet {
            guard let object = newValue else { return }
            self.cellImageView.image = object.image
            self.orderNameLabel.text = object.name
            self.orderDetailsLabel.text = object.details
            self.orderPriceLabel.text = object.price
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
