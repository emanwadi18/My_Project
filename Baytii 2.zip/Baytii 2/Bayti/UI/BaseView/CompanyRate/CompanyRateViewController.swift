

import UIKit

struct CompanyRateModel {
    var image: UIImage?
    var name: String?
    var rate: Double?
    var rateComent:String?
    var date:String
}

class CompanyRateViewController: UIViewController {
    
    @IBOutlet weak var tabelView: UITableView!
    
    var data = [CompanyRateModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        fetchData()
        self.tabelView.delegate = self
        self.tabelView.dataSource = self
        self.tabelView.registerNib(CopmanRateTabelCell.self)
    }
    
    func fetchData() {
        self.data = [
            CompanyRateModel(image: UIImage(named: "1"), name: "ايمان", rate: 3.3, rateComent: "واااو ",date: "20/2/2022"),
            CompanyRateModel(image: UIImage(named: "2"), name: "سوسن", rate: 3.3, rateComent: "",date: "20/2/2022"),
            CompanyRateModel(image: UIImage(named: "3"), name: "صفية", rate: 3.3, rateComent: "",date: "20/2/2022")
        ]
        self.tabelView.reloadData()
    }
    
    @IBAction func backActio(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension CompanyRateViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueCell(CopmanRateTabelCell.self, for: indexPath)
        let object = self.data[indexPath.row]
        cell.object = object
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        let vc = self.getStoryboardView(CompanyDetailsViewController.self)
//        let object = self.data[indexPath.row]
//        vc.d = object
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

