//
//  CopmanRateTabelCell.swift
//  Bayti
//
//  Created by Ahmed Akram on 19/12/2022.
//

import UIKit

class CopmanRateTabelCell: UITableViewCell {

    @IBOutlet weak var rateView: RateView!
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var RateCometLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    var object: CompanyRateModel? {
        willSet {
            guard let object = newValue else { return }
            self.rateView.rate = object.rate ?? 0.0
            self.nameLabel.text = object.name
            self.RateCometLabel.text = object.rateComent
            self.dateLabel.text = object.date
            
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
