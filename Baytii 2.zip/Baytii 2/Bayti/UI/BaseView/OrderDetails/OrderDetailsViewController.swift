//
//  OrderDetailsViewController.swift
//  Bayti
//
//  Created by Ahmed Akram on 18/12/2022.
//

import UIKit

class OrderDetailsViewController: UIViewController {
    @IBOutlet weak var orderImageView: ImageViewDesign!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
