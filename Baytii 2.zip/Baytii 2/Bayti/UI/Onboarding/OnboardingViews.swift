

import UIKit
struct cellModel {
    var image: UIImage
    var titel: String
    var describtion: String
}
class OnboardingViews: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
   
    @IBOutlet weak var nextButton: ButtonDesign!
   
    @IBOutlet weak var skipButton: ButtonDesign!
    
    @IBOutlet weak var pageControll: UIPageControl!
   
    var data = [cellModel]()
   
    
    var isLastBage: Bool = false
    
    var indexPath = Int() {
        willSet {
            self.pageControll.currentPage = newValue
            if newValue + 1 == data.count {
                self.isLastBage = true
                self.nextButton.setTitle("الي التطبيق".localize(), for: .normal)
                self.skipButton.isHidden = true
            }else {
                self.isLastBage = false
                self.nextButton.setTitle("التالي".localize(), for: .normal)
                self.skipButton.isHidden = false
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupView()
        fetchData()
        
        
    }
    
    
}

extension OnboardingViews {
    @IBAction func continuAction (_ sender: UIButton) {
        if isLastBage {
            let vc = self.getStoryboardView(SignInViewController.self)
            self.userProfile.changeFirstRunStatus()
            self.navigationController?.setViewControllers([vc], animated: true)
        }else if !isLastBage {
            let visibleItems: NSArray = self.collectionView.indexPathsForVisibleItems as NSArray
            
            var minItem: NSIndexPath = visibleItems.object(at: 0) as! NSIndexPath
            for itr in visibleItems {
                
                if minItem.row > (itr as AnyObject).row {
                    minItem = itr as! NSIndexPath
                }
            }
            
            let nextItem = NSIndexPath(row: minItem.row + 1, section: 0)
            self.indexPath += 1
            self.collectionView.scrollToItem(at: nextItem as IndexPath, at: .left, animated: true)
        }
    }
    
    @IBAction func skipAction (_ sender: UIButton) {
        let vc = self.getStoryboardView(UserRoleViewController.self)
        self.userProfile.changeFirstRunStatus()
        self.navigationController?.setViewControllers([vc], animated: true)
    }
}
extension OnboardingViews {
    func setupView(){
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.collectionView.registerNib(WillcomeCollectionCell.self)
        
        let btnAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 20, weight: .medium),
            .underlineStyle: NSUnderlineStyle.single.rawValue,
            .foregroundColor: UIColor.gray
        ] // .double.rawValue, .thick.rawValue
        /// Text Translations...
        self.skipButton.setAttributedTitle(
            NSMutableAttributedString(string: "تخطي".localize(), attributes: btnAttributes),
            for: .normal
        )
    }
    
    func fetchData(){
        self.data = [
            cellModel(image: UIImage(named: "1")!, titel: "استشارات هندسية", describtion: "استشارات هندسية استشارات هندسية استشارات هندسية استشارات هندسية"),
            cellModel(image: UIImage(named: "2")!, titel: "استشارات هندسية", describtion: "استشارات هندسية استشارات هندسية استشارات هندسية استشارات هندسية"),
            cellModel(image: UIImage(named: "3")!, titel: "استشارات هندسية", describtion: "استشارات هندسية استشارات هندسية استشارات هندسية استشارات هندسية")
        ]
        self.collectionView.reloadData()
        
    }
}

extension OnboardingViews: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.data.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueCell(WillcomeCollectionCell.self, for: indexPath)
        let object = data[indexPath.row]
        cell.object = object
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let flowLayout: UICollectionViewFlowLayout = collectionViewLayout as! UICollectionViewFlowLayout
        let leftRightPadding: CGFloat = flowLayout.sectionInset.left + flowLayout.sectionInset.right
        let spaceBetweenCells: CGFloat = flowLayout.minimumInteritemSpacing
        
        let cellWidth = (collectionView.width - leftRightPadding - spaceBetweenCells)
        return CGSize(width: cellWidth, height: collectionView.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if scrollView == self.collectionView {
            var currentCellOffset = self.collectionView.contentOffset
            currentCellOffset.x += self.collectionView.frame.width / 2
            if let indexPath = self.collectionView.indexPathForItem(at: currentCellOffset) {
                self.indexPath = indexPath.row
                self.collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
            }
        }
    }
}

extension UICollectionViewFlowLayout {
    
    open override var flipsHorizontallyInOppositeLayoutDirection: Bool {
        return true
    }
}
