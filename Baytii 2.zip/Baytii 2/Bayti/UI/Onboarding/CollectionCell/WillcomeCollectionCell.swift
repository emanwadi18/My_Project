//
//  WillcomeCollectionCell.swift
//  AjnadeenCard
//
//  Created by Ahmed Akram on 20/08/2022.
//

import UIKit

class WillcomeCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImageView: UIImageView!
    @IBOutlet weak var cellTitelLabel: UILabel!
    @IBOutlet weak var cellDescribtionLabel: UILabel!
    
    var object: cellModel? {
        willSet {
            guard let object = newValue else { return }
            self.cellImageView.image = object.image
            self.cellTitelLabel.text = object.titel
            self.cellDescribtionLabel.text = object.describtion
        }
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
