

import UIKit

class SginUpViewController: UIViewController {
    
    @IBOutlet weak var photoImageView: UIImageView!
    
    var profileImagePaker : UIImagePickerController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func sginInAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func sginUpAction(_ sender: Any) {
        let vc  = getStoryboardView(TabBarViewController.self)
        self.navigationController?.setViewControllers([vc], animated: true)
    }
    
    
    @IBAction func chooseImageAction(_ sender: Any) {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let picker = UIImagePickerController()
        picker.delegate = self
        
        alert.addAction(UIAlertAction(title: "كاميرا".localize(), style: .default, handler: { [weak self] (action) in
            guard let self = self else { return }
            picker.sourceType = .camera
            self.present(picker, animated: true)
        }))
        
        alert.addAction(UIAlertAction(title: "الالبوم".localize(), style: .default, handler: { [weak self] (action) in
            guard let self = self else { return }
            picker.sourceType = .photoLibrary
            self.present(picker, animated: true)
        }))
        
        alert.addAction(UIAlertAction(title: "الغاء".localize(), style: .cancel))
        
        self.present(alert, animated: true)
        
    }
}

// MARK: - IMAGE PICKER DELEGATE

extension SginUpViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[.originalImage] as? UIImage else { return }
        self.photoImageView.image = image
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}

