

import UIKit

class SignInViewController: UIViewController {

    @IBOutlet weak var emailTextFeaild: TextFieldDesign!
    @IBOutlet weak var passwordTextField: TextFieldDesign!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.emailTextFeaild.text = "test@test.com"
        self.passwordTextField.text = "12345678"
        self.passwordTextField.isSecureTextEntry = true
        
    }
    

    

    @IBAction func fprgetPasswordAction(_ sender: Any) {
    }
    @IBAction func sginInAction(_ sender: Any) {
        guard emailTextFeaild.text == "test@test.com",
              passwordTextField.text == "12345678" else {
            self.view.tostWithComplection(message: "تاكد من البيانات وحاول مجددا")
            return }
        
        let vc = self.getStoryboardView(TabBarViewController.self)
        self.navigationController?.setViewControllers([vc], animated: true)
    }
    @IBAction func sginUpAction(_ sender: Any) {
        let vc = self.getStoryboardView(SginUpViewController.self)
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}


